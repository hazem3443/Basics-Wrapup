/*
 * help_func.h
 *
 *  Created on: Sep 30, 2021
 *      Author: root
 */

#ifndef INC_HELP_FUNC_H_
#define INC_HELP_FUNC_H_

void str_empty(char str[]);

int len_str(char str[]);
int find_str(char str1[],char str2[]);
int find_strL(char str1[],char str2[]);
void concatenate(char str1[], char str2[]);
void int2char(int num, char str[]);
int char2int(char str[]);

#endif /* INC_HELP_FUNC_H_ */
